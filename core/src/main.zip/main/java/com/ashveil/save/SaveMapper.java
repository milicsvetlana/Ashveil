package com.ashveil.save;

import com.ashveil.Config;
import com.ashveil.combat.Projectile;
import com.ashveil.combat.ProjectileSystem;
import com.ashveil.entities.Player;
import com.ashveil.entities.enemies.Enemy;
import com.ashveil.entities.enemies.EnemySpawnSystem;
import com.ashveil.entities.enemies.EnemyType;
import com.ashveil.farming.*;
import com.ashveil.guidance.GuidanceSystem;
import com.ashveil.guidance.GuideStep;
import com.ashveil.items.crafting.CraftingCategory;
import com.ashveil.items.inventory.ItemStack;
import com.ashveil.items.inventory.ItemType;
import com.ashveil.objects.Chest;
import com.ashveil.objects.ChestKind;
import com.ashveil.objects.DestructibleObject;
import com.ashveil.objects.DestructibleObjectType;
import com.ashveil.progression.ProgressionState;
import com.ashveil.save.data.*;
import com.ashveil.world.DayNightCycle;
import com.ashveil.world.DayPhase;
import com.ashveil.world.World;
import com.ashveil.world.WorldItem;
import com.ashveil.world.area.AreaID;
import com.ashveil.world.area.AreaRuntime;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class SaveMapper {

    public World createWorld(SaveData saveData){
        if (saveData == null) throw new IllegalArgumentException("SaveData can't be null.");

        AreaID currentAreaId = AreaID.valueOf(saveData.currentAreaId);
        World world = World.createForLoad(currentAreaId, saveData.player.x, saveData.player.y);

        applyWorldState(world, saveData);
        applyPlayerState(world.getPlayer(), saveData.player);
        applyProgressionState(world.getProgressionState(), saveData.progressionState);

        applyDayNightState(world.getDayNightCycle(), saveData.dayNight);

        for (AreaSaveData areaSaveData : saveData.areas){
            AreaID areaID = AreaID.valueOf(areaSaveData.areaId);
            AreaRuntime runtime = world.getOrCreateAreaRuntimeForLoad(areaID);
            applyAreaState(runtime, areaSaveData);
        }

        world.updateBoatVisibility();

        applyGuidanceState(world.getGuidanceSystem(), saveData.guidance);
        return world;
    }

    private void applyAreaState(AreaRuntime runtime, AreaSaveData areaSaveData){
        runtime.applyPersistentState(areaSaveData.lastDepartureDayCount, areaSaveData.ordinaryNighDayCount);
        applyDestructibleObjectState(runtime, areaSaveData);
        applyFarmingState(runtime.getFarmingSystem(), areaSaveData);
        applyGroundItemState(runtime, areaSaveData);
        applyEnemyState(runtime, areaSaveData);
        applyProjectileState(runtime.getProjectileSystem(), areaSaveData);
        applyNightSpawnState(runtime.getEnemySpawnSystem(), areaSaveData.nightSpawn);
    }

    public void applyDestructibleObjectState(AreaRuntime runtime, AreaSaveData areaSaveData){
        for (DestructibleObjectSaveData objectSaveData : areaSaveData.destructibleObjects){
            DestructibleObjectType type = DestructibleObjectType.valueOf(objectSaveData.objectType);
            DestructibleObject object;

            if (type == DestructibleObjectType.CHEST){
                ChestKind chestKind = ChestKind.valueOf(objectSaveData.chestKind);

                object = runtime.getDestructibleObjectSystem().createAndAddChest(objectSaveData.x, objectSaveData.y, objectSaveData.currentHp, chestKind);
            }
            else {
                object = runtime.getDestructibleObjectSystem().createAndAdd(objectSaveData.x, objectSaveData.y, type, objectSaveData.currentHp);
            }


            if (object instanceof Chest chest){
                ItemStack[] chestContents = createInventoryContents(objectSaveData.chestInventory, Config.CHEST_INVENTORY_SIZE);
                chest.getChestInventory().replaceContents(chestContents);
            }
        }
    }

    private void applyWorldState(World world, SaveData saveData){
        world.applyPersistentState(saveData.player.checkPointX, saveData.player.checkPointY, saveData.playTimeSeconds);
    }

    private void applyPlayerState(Player player, PlayerSaveData playerSaveData){
        player.setPosition(playerSaveData.x, playerSaveData.y);

        if (playerSaveData.characterName != null && !playerSaveData.characterName.isBlank())
            player.setCharacterName(playerSaveData.characterName);


        ItemStack[] inventoryContents = createInventoryContents(playerSaveData.inventory, Config.INVENTORY_SIZE);
        player.applyPersistentState(playerSaveData.health, playerSaveData.brokenHearts, playerSaveData.gold,
                                    playerSaveData.selectedHotbarSlot, inventoryContents);
    }

    private void applyDayNightState(DayNightCycle dayNightCycle, DayNightSaveData dayNightSaveData){
        DayPhase phase = DayPhase.valueOf(dayNightSaveData.phase);
        dayNightCycle.applyPersistentState(dayNightSaveData.dayCount, phase, dayNightSaveData.phaseTimer);
    }

    private void applyProgressionState(ProgressionState progressionState, ProgressionSaveData progressionSaveData){
        EnumSet<CraftingCategory> unlockedCategories = EnumSet.noneOf(CraftingCategory.class);
        for (String categoryName : progressionSaveData.unlockedCraftingCategories){
            unlockedCategories.add(CraftingCategory.valueOf(categoryName));
        }

        EnumSet<AreaID> unlockedAreas = EnumSet.noneOf(AreaID.class);
        if (progressionSaveData.unlockedAreas != null){
            for (String areaName : progressionSaveData.unlockedAreas){
                unlockedAreas.add(AreaID.valueOf(areaName));
            }
        }

        if (unlockedAreas.isEmpty()){
            unlockedAreas.add(AreaID.MAIN_ISLAND);
            unlockedAreas.add(AreaID.WINDY_PLAINS);
        }

        progressionState.applyPersistentState(progressionSaveData.firstTreeDropClaimed, progressionSaveData.wispNightUnlocked,
                                              progressionSaveData.wraithNightUnlocked, progressionSaveData.boatKitCrafted,
                                              progressionSaveData.boatBuilt, progressionSaveData.foundOldJetty,
                                              progressionSaveData.scrollIRead, progressionSaveData.scrollIIRead,
                                              progressionSaveData.scrollIIIRead, unlockedCategories, unlockedAreas,
                                              progressionSaveData.windyWardCleared, progressionSaveData.dashUnlocked);
    }

    private void applyFarmingState(FarmingSystem farmingSystem, AreaSaveData areaSaveData){
        for (TilledTileSaveData tileData : areaSaveData.tilledTiles){
            farmingSystem.till(tileData.tileX, tileData.tileY);
        }

        for (PlantSaveData plantData : areaSaveData.plants){
            if ("CROP".equals(plantData.plantKind)){
                CropType cropType = CropType.valueOf(plantData.cropType);
                farmingSystem.plant(cropType, plantData.tileX, plantData.tileY);
            }
            else if ("SAPLING".equals(plantData.plantKind)){
                farmingSystem.plantSapling(plantData.tileX, plantData.tileY);
            }

            GrowablePlant plant = farmingSystem.getPlant(plantData.tileX, plantData.tileY);
            plant.restoreGrowthTimer(plantData.growthTimer);
        }
    }

    private void applyGroundItemState(AreaRuntime runtime, AreaSaveData areaSaveData){
        List<WorldItem> restoredItems = new ArrayList<>();
        for (WorldItemSaveData itemSaveData : areaSaveData.groundItems){
            ItemType itemType = ItemType.valueOf(itemSaveData.itemType);
            ItemStack itemStack = new ItemStack(itemType, itemSaveData.quantity, itemSaveData.durability);
            restoredItems.add(new WorldItem(itemSaveData.x, itemSaveData.y, itemStack));
        }
        runtime.getWorldItemSystem().replaceItems(restoredItems);
    }

    private void applyEnemyState(AreaRuntime runtime, AreaSaveData areaSaveData){
        for (EnemySaveData enemySaveData : areaSaveData.enemies){
            EnemyType enemyType = EnemyType.valueOf(enemySaveData.enemyType);
            runtime.getEnemySpawnSystem().createAndAddEnemy(enemyType, enemySaveData.x, enemySaveData.y, enemySaveData.currentHp);
        }
    }

    private void applyProjectileState(ProjectileSystem projectileSystem, AreaSaveData areaSaveData){
        List<Projectile> restoredProjectiles = new ArrayList<>();

        for (ProjectileSaveData projectileSaveData : areaSaveData.projectiles){
            restoredProjectiles.add(Projectile.fromVelocity(projectileSaveData.x, projectileSaveData.y, projectileSaveData.velocityX,
                                                             projectileSaveData.velocityY, projectileSaveData.damage, projectileSaveData.remainingLifetime));
        }
        projectileSystem.replaceProjectiles(restoredProjectiles);
    }

    private void applyNightSpawnState(EnemySpawnSystem enemySpawnSystem, NightSpawnSaveData nightSpawnSaveData){
        List<EnemyType> remainingQueue = new ArrayList<>();

        for (String enemyTypeName : nightSpawnSaveData.remainingQueue){
            remainingQueue.add(EnemyType.valueOf(enemyTypeName));
        }

        enemySpawnSystem.applyPersistentState(remainingQueue, nightSpawnSaveData.spawnTimer, nightSpawnSaveData.spawnInterval);
    }

    private void applyGuidanceState(GuidanceSystem guidanceSystem, GuidanceSaveData guidanceSaveData){
        if (guidanceSaveData == null) return;

        try{
            GuideStep currentStep = guidanceSaveData.currentStep == null ? null : GuideStep.valueOf(guidanceSaveData.currentStep);
            GuideStep activeContextualStep = guidanceSaveData.activeContextualStep == null ? null : GuideStep.valueOf(guidanceSaveData.activeContextualStep);
            EnumSet<GuideStep> shownContextualSteps = EnumSet.noneOf(GuideStep.class);

            if (guidanceSaveData.shownContextualSteps != null){
                for (String stepName : guidanceSaveData.shownContextualSteps){
                    try{
                        shownContextualSteps.add(GuideStep.valueOf(stepName));
                    }
                    catch(IllegalArgumentException ignored){}
                }
            }

            guidanceSystem.applyPersistentState(currentStep, guidanceSaveData.triggerSatisfied,
                guidanceSaveData.messageAcknowledged, shownContextualSteps, activeContextualStep);
        }
        catch (IllegalArgumentException ignored){}
    }

    private ItemStack[] createInventoryContents(List<ItemStackSaveData> itemDataList, int inventorySize){
        ItemStack [] contents = new ItemStack[inventorySize];
        for (ItemStackSaveData itemData : itemDataList){
            ItemType itemType = ItemType.valueOf(itemData.itemType);
            contents[itemData.slot] = new ItemStack(itemType, itemData.quantity, itemData.durability);
        }
        return contents;
    }

    public SaveData createSaveData(World world){
        SaveData saveData = new SaveData();

        saveData.saveVersion = SaveConstants.CURRENT_SAVE_VERSION;
        saveData.savedAt = System.currentTimeMillis();
        saveData.playTimeSeconds = world.getTotalPlayTimeSeconds();

        saveData.player = createPlayerSaveData(world.getPlayer());
        saveData.player.checkPointX = world.getCheckpointX();
        saveData.player.checkPointY = world.getCheckpointY();
        saveData.dayNight = createDayNightSaveData(world.getDayNightCycle());
        saveData.progressionState = createProgressionSaveData(world.getProgressionState());
        saveData.guidance = createGuidanceSaveData(world.getGuidanceSystem());

        saveData.currentAreaId = world.getAreaManager().getCurrentAreaId().name();
        for (AreaRuntime runtime : world.getInitializedAreaRuntimes()){
            saveData.areas.add(createAreaSaveData(runtime));
        }

        return saveData;
    }

    public PlayerSaveData createPlayerSaveData(Player player){
        PlayerSaveData playerData = new PlayerSaveData();
        playerData.characterName = player.getCharacterName();
        playerData.x = player.getX();
        playerData.y = player.getY();
        playerData.health = player.getCurrentHp();
        playerData.selectedHotbarSlot = player.getSelectedHotbarSlot();
        playerData.brokenHearts = player.getBrokenHearts();
        playerData.gold = player.getWallet().getGold();
        for (int i=0; i < Config.INVENTORY_SIZE; i++){
            ItemStack itemStack = player.getInventory().getSlot(i);
            if (itemStack == null) continue;

            playerData.inventory.add(createItemStackSaveData(itemStack, i));
        }
        return playerData;
    }

    private ItemStackSaveData createItemStackSaveData(ItemStack itemStack, int slot){
        ItemStackSaveData itemData = new ItemStackSaveData();
        itemData.slot = slot;
        itemData.itemType = itemStack.getType().name();
        itemData.quantity = itemStack.getQuantity();
        itemData.durability = itemStack.getDurability();
        return itemData;
    }

    public DayNightSaveData createDayNightSaveData(DayNightCycle dayNightCycle){
        DayNightSaveData dayNightSaveData = new DayNightSaveData();

        dayNightSaveData.dayCount = dayNightCycle.getDayCount();
        dayNightSaveData.phase = dayNightCycle.getDayPhase().name();
        dayNightSaveData.phaseTimer = dayNightCycle.getPhaseTimer();

        return dayNightSaveData;
    }

    private ProgressionSaveData createProgressionSaveData(ProgressionState progressionState){
        ProgressionSaveData progressionSaveData = new ProgressionSaveData();
        progressionSaveData.firstTreeDropClaimed = progressionState.isFirstTreeDropClaimed();
        progressionSaveData.wispNightUnlocked = progressionState.isWispNightUnlocked();
        progressionSaveData.wraithNightUnlocked = progressionState.isWraithNightUnlocked();

        progressionSaveData.boatKitCrafted = progressionState.isBoatKitCrafted();
        progressionSaveData.boatBuilt  = progressionState.isBoatBuilt();
        progressionSaveData.foundOldJetty  = progressionState.isOldJettyFound();

        progressionSaveData.scrollIRead = progressionState.isScrollIRead();
        progressionSaveData.scrollIIRead = progressionState.isScrollIIRead();
        progressionSaveData.scrollIIIRead = progressionState.isScrollIIIRead();

        for (CraftingCategory category : progressionState.getUnlockedCraftingCategories()){
            progressionSaveData.unlockedCraftingCategories.add(category.name());
        }

        for (AreaID areaID : AreaID.values()){
            if (progressionState.isAreaUnlocked(areaID)){
                progressionSaveData.unlockedAreas.add(areaID.name());
            }
        }

        progressionSaveData.windyWardCleared = progressionState.isWardCleared(AreaID.WINDY_PLAINS);
        progressionSaveData.dashUnlocked = progressionState.isDashUnlocked();

        return progressionSaveData;
    }

    private AreaSaveData createAreaSaveData(AreaRuntime runtime){
        AreaSaveData areaSaveData = new AreaSaveData();
        areaSaveData.areaId = runtime.getAreaID().name();

        for (DestructibleObject object : runtime.getDestructibleObjectSystem().getObjects()){
            areaSaveData.destructibleObjects.add(createDestructibleObjectSaveData(object));
        }

        addFarmingSaveData(runtime.getFarmingSystem(), areaSaveData);

        for (WorldItem groundItem : runtime.getWorldItemSystem().getItems()){
            areaSaveData.groundItems.add(createWorldItemSaveData(groundItem));
        }

        for (Enemy enemy : runtime.getEnemies()){
            if (!enemy.isAlive()) continue;
            areaSaveData.enemies.add(createEnemySaveData(enemy));
        }

        for (Projectile projectile : runtime.getProjectileSystem().getProjectiles()){
            if (!projectile.isActive()) continue;
            areaSaveData.projectiles.add(createProjectileSaveData(projectile));
        }

        areaSaveData.nightSpawn = createNightSpawnSaveData(runtime.getEnemySpawnSystem());
        areaSaveData.lastDepartureDayCount = runtime.getLastDepartureDayCount();
        areaSaveData.ordinaryNighDayCount = runtime.getOrdinaryNightDayCount();

        return areaSaveData;
    }

    private DestructibleObjectSaveData createDestructibleObjectSaveData(DestructibleObject object){
        DestructibleObjectSaveData destructibleObjectSaveData = new DestructibleObjectSaveData();
        destructibleObjectSaveData.objectType = object.getType().name();
        destructibleObjectSaveData.x = object.getX();
        destructibleObjectSaveData.y = object.getY();
        destructibleObjectSaveData.currentHp = object.getCurrenthp();

        if (object instanceof Chest chest){
            destructibleObjectSaveData.chestKind = chest.getKind().name();
            for (int i=0; i < chest.getChestInventory().getSize(); i++){
                ItemStack itemStack = chest.getChestInventory().getSlot(i);
                if (itemStack == null) continue;
                destructibleObjectSaveData.chestInventory.add(createItemStackSaveData(itemStack, i));
            }
        }
        return destructibleObjectSaveData;
    }

    private PlantSaveData createPlantSaveData(GrowablePlant plant, int tileX, int tileY){
        PlantSaveData plantSaveData = new PlantSaveData();
        plantSaveData.tileX = tileX;
        plantSaveData.tileY = tileY;
        plantSaveData.growthTimer = plant.getGrowthTimer();

        if (plant instanceof Crop crop){
            plantSaveData.plantKind = "CROP";
            plantSaveData.cropType = crop.getCropType().name();
        }
        else if (plant instanceof Sapling){
            plantSaveData.plantKind = "SAPLING";
            plantSaveData.cropType = null;
        }
        else throw new IllegalStateException("Unsupported plant type " + plant.getClass().getSimpleName());

        return plantSaveData;
    }

    private void addFarmingSaveData(FarmingSystem farmingSystem, AreaSaveData areaSaveData) {
        for (int x = 0; x < farmingSystem.getWidth(); x++) {
            for (int y = 0; y < farmingSystem.getHeight(); y++) {
                if (farmingSystem.isTilled(x, y)) {
                    TilledTileSaveData tilledTileSaveData = new TilledTileSaveData();
                    tilledTileSaveData.tileX = x;
                    tilledTileSaveData.tileY = y;
                    areaSaveData.tilledTiles.add(tilledTileSaveData);
                }

                GrowablePlant plant = farmingSystem.getPlant(x, y);
                if (plant == null) continue;
                areaSaveData.plants.add(createPlantSaveData(plant, x, y));
            }
        }
    }

    private WorldItemSaveData createWorldItemSaveData(WorldItem worldItem){
        WorldItemSaveData worldItemSaveData = new WorldItemSaveData();
        worldItemSaveData.x = worldItem.getX();
        worldItemSaveData.y = worldItem.getY();
        worldItemSaveData.itemType = worldItem.getType().name();
        worldItemSaveData.quantity = worldItem.getStack().getQuantity();
        worldItemSaveData.durability = worldItem.getStack().getDurability();
        return worldItemSaveData;
    }

    private EnemySaveData createEnemySaveData(Enemy enemy){
        EnemySaveData enemySaveData = new EnemySaveData();
        enemySaveData.enemyType = enemy.getEnemyType().name();
        enemySaveData.x = enemy.getX();
        enemySaveData.y = enemy.getY();
        enemySaveData.currentHp = enemy.getCurrentHp();
        return enemySaveData;
    }

    private ProjectileSaveData createProjectileSaveData(Projectile projectile){
        ProjectileSaveData projectileSaveData = new ProjectileSaveData();
        projectileSaveData.x = projectile.getX();
        projectileSaveData.y = projectile.getY();
        projectileSaveData.velocityX = projectile.getVelocityX();
        projectileSaveData.velocityY = projectile.getVelocityY();
        projectileSaveData.damage = projectile.getDamage();
        projectileSaveData.remainingLifetime = projectile.getLifetime();
        return projectileSaveData;
    }

    private NightSpawnSaveData createNightSpawnSaveData(EnemySpawnSystem enemySpawnSystem){
        NightSpawnSaveData nightSpawnSaveData = new NightSpawnSaveData();
        nightSpawnSaveData.spawnTimer = enemySpawnSystem.getSpawnTimer();
        nightSpawnSaveData.spawnInterval = enemySpawnSystem.getSpawnInterval();

        for (EnemyType enemyType : enemySpawnSystem.getRemainingSpawnQueue()){
            nightSpawnSaveData.remainingQueue.add(enemyType.name());
        }

        return nightSpawnSaveData;
    }

    private GuidanceSaveData createGuidanceSaveData(GuidanceSystem guidanceSystem){
        GuidanceSaveData guidanceSaveData = new GuidanceSaveData();
        GuideStep currentStep = guidanceSystem.getCurrentStep();
        guidanceSaveData.currentStep = currentStep == null ? null : currentStep.name();

        GuideStep activeContextualStep = guidanceSystem.getActiveContextualStep();
        guidanceSaveData.activeContextualStep = activeContextualStep == null ? null : activeContextualStep.name();

        guidanceSaveData.triggerSatisfied = guidanceSystem.isCurrentTriggerSatisfied();
        guidanceSaveData.messageAcknowledged = guidanceSystem.isMessageAcknowledged();

        for (GuideStep step : guidanceSystem.getShownContextualSteps()){
            guidanceSaveData.shownContextualSteps.add(step.name());
        }

        return guidanceSaveData;
    }

}

