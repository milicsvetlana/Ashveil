package com.ashveil.world;

import com.ashveil.Config;
import com.ashveil.combat.CombatSystem;
import com.ashveil.combat.Hittable;
import com.ashveil.combat.ProjectileSystem;
import com.ashveil.economy.ShopAccess;
import com.ashveil.economy.ShopItem;
import com.ashveil.encounter.*;
import com.ashveil.entities.enemies.*;
import com.ashveil.entities.Player;
import com.ashveil.farming.*;
import com.ashveil.guidance.GameEvent;
import com.ashveil.guidance.GuidanceSystem;
import com.ashveil.items.crafting.*;
import com.ashveil.items.inventory.ItemStack;
import com.ashveil.items.inventory.ItemType;
import com.ashveil.objects.*;
import com.ashveil.input.PlayerInput;
import com.ashveil.progression.ProgressionState;
import com.ashveil.targeting.TargetMode;
import com.ashveil.ui.reward.RewardType;
import com.ashveil.world.area.AreaID;
import com.ashveil.world.area.AreaManager;
import com.ashveil.world.area.AreaRuntime;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.util.*;

public class World implements CraftingAccess, WorldMapAccess, ShopAccess {

    private final Random random = new Random();

    private final AreaManager areaManager;

    private final Player player;

    private final CombatSystem combatSystem;

    private final CraftingManager craftingManager;
    private final ProgressionState progressionState;
    private final GuidanceSystem guidanceSystem;
    private final DayNightCycle dayNightCycle;

    private final Map<AreaID, AreaRuntime> areaRuntimes;
    private AreaRuntime currentAreaRuntime;

    private TargetMode targetMode;
    private Chest activeChest;
    private Rectangle targetBounds;

    private float checkpointX;
    private float checkpointY;

    private double totalPlayTimeSeconds;
    private float boatTravelCooldownRemaining;

    private boolean worldMapRequested;
    private ItemType scrollReadRequested;
    private RewardType rewardRequested;
    private boolean departureRequested;

    private GuardianEncounter guardianEncounter;
    private boolean windyGuardianStartedRequested;

    private final CrimsonVeilSystem crimsonVeilSystem;
    private final AshenRiteSystem ashenRiteSystem;

    public World(){
        areaManager = new AreaManager(AreaID.MAIN_ISLAND);

        progressionState = new ProgressionState();
        guidanceSystem = new GuidanceSystem();
        combatSystem = new CombatSystem();
        craftingManager = new CraftingManager(progressionState);
        dayNightCycle = new DayNightCycle();
        crimsonVeilSystem = new CrimsonVeilSystem();
        ashenRiteSystem = new AshenRiteSystem();

        player = new Player(0f, 0f);

        areaRuntimes = new EnumMap<>(AreaID.class);
        AreaRuntime mainIsland = new AreaRuntime(areaManager.getCurrentArea(), player, progressionState);

        areaRuntimes.put(AreaID.MAIN_ISLAND, mainIsland);
        currentAreaRuntime = mainIsland;

        player.setAreaEnvironment(currentAreaRuntime.getTileMap(), currentAreaRuntime.getCollisionSystem());
        updateBoatVisibility();

        Vector2 playerSpawn = currentAreaRuntime.getTileMap().getObjectPosition("Objects", "player_spawn");
        player.setPosition(playerSpawn.x, playerSpawn.y);
        checkpointX = playerSpawn.x;
        checkpointY = playerSpawn.y;

        initializeNewGameState();

        targetMode = TargetMode.NONE;
        targetBounds = new Rectangle();
        activeChest = null;

        totalPlayTimeSeconds = 0;
        boatTravelCooldownRemaining = 0;

        worldMapRequested = false;
        scrollReadRequested = null;
        rewardRequested = null;
        departureRequested = false;

        guardianEncounter = null;
        windyGuardianStartedRequested = false;
    }

    private World(AreaID areaId, float playerX, float playerY){
        areaManager = new AreaManager(areaId);
        progressionState = new ProgressionState();
        guidanceSystem = new GuidanceSystem();
        combatSystem = new CombatSystem();
        craftingManager = new CraftingManager(progressionState);
        dayNightCycle = new DayNightCycle();
        crimsonVeilSystem = new CrimsonVeilSystem();
        ashenRiteSystem = new AshenRiteSystem();

        player = new Player(playerX, playerY);

        areaRuntimes = new EnumMap<>(AreaID.class);

        AreaRuntime loadedArea = new AreaRuntime(areaManager.getCurrentArea(), player, progressionState);
        areaRuntimes.put(areaId, loadedArea);
        currentAreaRuntime = loadedArea;

        player.setAreaEnvironment(currentAreaRuntime.getTileMap(), currentAreaRuntime.getCollisionSystem());

        checkpointX = playerX;
        checkpointY = playerY;

        targetMode = TargetMode.NONE;
        targetBounds = new Rectangle();
        activeChest = null;

        totalPlayTimeSeconds = 0;
        boatTravelCooldownRemaining = 0;

        worldMapRequested = false;
        scrollReadRequested = null;
        rewardRequested = null;
        departureRequested = false;

        guardianEncounter = null;
        windyGuardianStartedRequested = false;
    }

    private void initializeNewGameState(){
        currentAreaRuntime.getDestructibleObjectSystem().spawnInitialResources(player, getNaturalResourceTypes(AreaID.MAIN_ISLAND));
        spawnStarterChest();
    }

    private void spawnStarterChest(){
        float chestX = player.getX() + Config.TILE_SIZE * 2f;
        float chestY = player.getY();

        Chest chest = (Chest) currentAreaRuntime.getDestructibleObjectSystem().createAndAdd(chestX, chestY, DestructibleObjectType.CHEST);

        chest.getChestInventory().addItem(ItemType.STONE_HOE, 1);
        chest.getChestInventory().addItem(ItemType.WHEAT_SEED, 5);
        chest.getChestInventory().addItem(ItemType.BOAT_KIT, 1);
    }

    public static World createForLoad(AreaID areaID, float playerX, float playerY){
        if (areaID == null) throw new IllegalArgumentException("Area id cannot be null");
        return new World(areaID, playerX, playerY);
    }

    public void update(float delta, PlayerInput playerInput){
        totalPlayTimeSeconds += delta;
        if (boatTravelCooldownRemaining >= 0f){
            boatTravelCooldownRemaining = Math.max(0f, boatTravelCooldownRemaining - delta);
        }
        player.update(delta);
        player.move(playerInput.getMoveX(), playerInput.getMoveY(), delta);

        handleDash(playerInput);
        handlePlayerHazard();

        currentAreaRuntime.getDistanceField().update(getTileMap().worldToTileX(player.getCenterX()), getTileMap().worldToTileY(player.getCenterY()));

        getFarmingSystem().update(delta);
        handleMatureSaplings();

        for (Enemy e : getEnemies()) e.update(delta);
        getProjectileSystem().update(delta);

        if (!isGuardianEncounterActive()){

            if (crimsonVeilSystem.isActive() || crimsonVeilSystem.isRecovery() || ashenRiteSystem.blocksDayNightCycle())
                dayNightCycle.update(0f);
            else dayNightCycle.update(delta);

            if (dayNightCycle.justBecameDusk()){
                guidanceSystem.handleEvent(GameEvent.DUSK_STARTED);

                boolean crimsonWarningStarted = crimsonVeilSystem.handleDuskStarted(dayNightCycle.getDayCount());
                if (crimsonWarningStarted) guidanceSystem.handleEvent(GameEvent.CRIMSON_VEIL_WARNING, progressionState);
            }

            if (dayNightCycle.justBecameNight() && !ashenRiteSystem.blocksDayNightCycle()){
                boolean crimsonStarted = crimsonVeilSystem.handleNightStarted(dayNightCycle.getDayCount());
                if (crimsonStarted){
                    getEnemySpawnSystem().endNight();
                    getEnemies().clear();
                    getProjectileSystem().replaceProjectiles(List.of());

                    startCrimsonVeilWave();
                }
                else startOrdinaryNightForCurrentArea();
            }

            if (dayNightCycle.isNight() && !crimsonVeilSystem.isActive() && !crimsonVeilSystem.isRecovery()
                && !ashenRiteSystem.blocksDayNightCycle())
                getEnemySpawnSystem().update(delta);

            if (crimsonVeilSystem.isActive()){
                getEnemySpawnSystem().update(delta);
            }
            if (ashenRiteSystem.isLastVeil()){
                getEnemySpawnSystem().update(delta);
            }
        }

        handleHotbarSelection(playerInput);
        handlePrimaryAction(playerInput);
        handleInteract(playerInput);
        handleDropItem(playerInput);
        handleUseItem(playerInput);
        getDestructibleObjectSystem().processBriarSnareTrigger(getEnemies());
        getDestructibleObjectSystem().processDestroyedObjects();

        getWorldItemSystem().update(delta);

        for (Enemy enemy : getEnemies()){
            if (!enemy.shouldBeRemoved()) continue;
            if (!enemy.wasKilled()) continue;
            int goldDrop = getRandomGoldDrop();
            if (goldDrop <= 0) continue;
            getWorldItemSystem().add(new WorldItem(enemy.getX(), enemy.getY(), ItemType.GOLD, goldDrop));
        }
        getEnemies().removeIf(Enemy::shouldBeRemoved);

        updateCrimsonVeil(delta);
        updateLastVeil(delta);
        updateAshenRiteReveal();
        if (dayNightCycle.justBecameDay()) handleDayStarted();
        updateGuardianEncounter();
        updateScrollProgression();
    }

    private void updateCrimsonVeil(float delta){
        if (crimsonVeilSystem.isActive()){
            boolean shouldAdvance = crimsonVeilSystem.shouldAdvanceWave(delta, !getEnemies().isEmpty(), getEnemySpawnSystem().hasPendingSpawns());

            if (!shouldAdvance) return;

            if (crimsonVeilSystem.hasNextWave()){
                crimsonVeilSystem.advanceWave();
                startCrimsonVeilWave();
                return;
            }

            crimsonVeilSystem.completeVeil(dayNightCycle.getDayCount());

            getEnemySpawnSystem().endNight();
        }

        if (crimsonVeilSystem.isRecovery()){
            boolean recoveryFinished = crimsonVeilSystem.updateRecovery(delta);
            if (!recoveryFinished) return;

            crimsonVeilSystem.finishRecovery();
            dayNightCycle.forceDay();
        }
    }

    private void startOrdinaryNightForCurrentArea(){
        int dayCount = dayNightCycle.getDayCount();

        getEnemySpawnSystem().startNight(dayCount, currentAreaRuntime.getAreaID());
        currentAreaRuntime.markOrdinaryNightStarted(dayCount);
    }

    private void startCrimsonVeilWave(){
        getEnemySpawnSystem().startThreatWave(crimsonVeilSystem.getCurrentWaveBudget(),
                                              currentAreaRuntime.getAreaID(), Config.CRIMSON_VEIL_WAVE_SPAWN_DURATION);


    }

    private void handleDayStarted(){
        getEnemySpawnSystem().endNight();

        for (Enemy enemy : getEnemies()){
            enemy.startFleeing(getTileMap().getWidth() * Config.TILE_SIZE,
                               getTileMap().getHeight() * Config.TILE_SIZE
            );
        }
    }

    private void handlePrimaryAction(PlayerInput playerInput){
        if (playerInput.isPrimaryActionPressed() && player.canUsePrimaryAction()){

            List<Hittable> targets = new ArrayList<>();
            targets.addAll(getEnemies());
            targets.addAll(getDestructibleObjectSystem().getObjects());

            combatSystem.performPrimaryAction(player, targets);
            player.resetPrimaryActionCooldown();
        }
    }

    private int getRandomGoldDrop(){
        int roll = random.nextInt(100);
        if (roll < Config.DOUBLE_GOLD_DROP_CHANCE) return 2;
        if (roll < Config.DOUBLE_GOLD_DROP_CHANCE + Config.SINGLE_GOLD_DROP_CHANCE) return 1;
        return 0;
    }

    private void handleInteract(PlayerInput playerInput){
        if (!playerInput.isInteractPressed()) return;

        if (tryUseAshenRite()) return;
        if (tryUseBoat()) return;
        if (tryOpenChest()) return;
        if (tryHarvestCrop()) return;
        getWorldItemSystem().tryPickUpNearest(player);
    }

    private boolean tryOpenChest(){
        Chest nearestChest = getDestructibleObjectSystem().findNearestChest(player.getCenterX(), player.getCenterY(), Config.PLAYER_PICKUP_RANGE);
        if (nearestChest == null) return false;

        if (nearestChest.getKind() == ChestKind.GUARDIAN){
            AreaID areaID = currentAreaRuntime.getAreaID();

            if (!progressionState.isWardCleared(areaID)){
                GuardianEncounterDefinition definition = getGuardianDefinition(areaID);
                startGuardianEncounter(definition);
                return true;
            }
        }

        activeChest = nearestChest;
        return true;
    }

    private boolean tryHarvestCrop() {
        Crop nearestCrop = null;
        int nearestTileX = -1;
        int nearestTileY = -1;
        Double nearestDistanceSquared = null;

        for (int x=0; x < getTileMap().getWidth(); x++){
            for (int y=0; y < getTileMap().getHeight(); y++){
                if (!(getFarmingSystem().getPlant(x, y) instanceof Crop crop)) continue;

                if (crop.getGrowthStage() != GrowthStage.MATURE) continue;

                float cropWorldX = getTileMap().tileToWorldX(x);
                float cropWorldY = getTileMap().tileToWorldY(y);

                float dimX = cropWorldX - player.getX();
                float dimY = cropWorldY - player.getY();
                double dist = dimX * dimX + dimY * dimY;
                if (dist > Config.PLAYER_PICKUP_RANGE * Config.PLAYER_PICKUP_RANGE) continue;

                if (nearestDistanceSquared == null || dist < nearestDistanceSquared){
                    nearestDistanceSquared = dist;
                    nearestCrop = crop;
                    nearestTileX = x;
                    nearestTileY = y;
                }
            }
        }
        if (nearestCrop == null) return false;

        float tileWorldX = getTileMap().tileToWorldX(nearestTileX);
        float tileWorldY = getTileMap().tileToWorldY(nearestTileY);
        float wheatDropX = tileWorldX + Config.TILE_SIZE * 0.20f;
        float seedDropX = tileWorldX + Config.TILE_SIZE * 0.60f;
        float dropY = tileWorldY + Config.TILE_SIZE * 0.20f;
        getWorldItemSystem().add(new WorldItem(wheatDropX, dropY, ItemType.WHEAT, 1));

        int seedAmount = random.nextInt(100) < 75 ? 1 : 2;
        getWorldItemSystem().add(new WorldItem(seedDropX , dropY, ItemType.WHEAT_SEED, seedAmount));

        getFarmingSystem().removePlant(nearestTileX, nearestTileY);
        return true;
    }

    private void handleHotbarSelection(PlayerInput playerInput){
        int selectedSlot = playerInput.getSelectedHotbarSlot();
        if (selectedSlot == -1) return;
        if (selectedSlot == player.getSelectedHotbarSlot()) return;
        player.setSelectedHotbarSlot(selectedSlot);
        cancelTargeting();
    }

    private void handleDropItem(PlayerInput playerInput){
        if (!playerInput.isDropItemPressed()) return;
        ItemType itemType = player.getInventory().getItemTypeBySlot(player.getSelectedHotbarSlot());
        if (itemType == null) return;
        int quantity = 1;

        if (playerInput.isDropWholeStack()){
            quantity = player.getInventory().getQuantityBySlot(player.getSelectedHotbarSlot());
        }

        ItemStack itemStack = player.getInventory().extractFromSlot(player.getSelectedHotbarSlot(), quantity);

        if (itemStack == null) return;
        getWorldItemSystem().add(new WorldItem(
                                   player.getX() + (random.nextFloat(3) - 0.5f) * Config.TILE_SIZE,
                                   player.getY() + (random.nextFloat(3) - 0.5f) * Config.TILE_SIZE,
                                      itemStack));
    }

    private void handleUseItem(PlayerInput playerInput){
        if (!playerInput.isUseItemPressed()) return;

        int selectedSlot = player.getSelectedHotbarSlot();
        ItemType itemType = player.getInventory().getItemTypeBySlot(selectedSlot);

        if (itemType == null) return;

        if (itemType.getTargetMode() != TargetMode.NONE){
            if (targetMode == itemType.getTargetMode()) {
                targetMode = TargetMode.NONE;
            }
            else {
                targetMode = itemType.getTargetMode();
            }
            return;
        }

        if (targetMode != TargetMode.NONE){
            targetMode = TargetMode.NONE;
        }

        if (itemType == ItemType.SCROLL_I || itemType == ItemType.SCROLL_II || itemType == ItemType.SCROLL_III){
            scrollReadRequested = itemType;
            return;
        }

        if (itemType == ItemType.HEART_REPAIR){
            player.useHeartRepair();
            player.getInventory().removeFromSlot(selectedSlot, 1);
        }

        if (itemType == ItemType.BREAD){
            player.heal(Config.BREAD_HEALING);
            player.getInventory().removeFromSlot(selectedSlot, 1);
        }

        if (itemType == ItemType.HOLLOWCAP){
            player.heal(Config.HOLLOWCAP_HEALING);
            player.getInventory().removeFromSlot(selectedSlot, 1);
        }
    }

    private void handleDash(PlayerInput playerInput){
        if (!playerInput.isDashPressed()) return;
        if (!progressionState.isDashUnlocked()) return;

        player.dash(playerInput.getMoveX(), playerInput.getMoveY());
    }

    public boolean isCurrentTargetValid(int tileX, int tileY, float worldX, float worldY){
        if (tileX < 0 || tileY < 0 || tileX >= getTileMap().getWidth() || tileY >= getTileMap().getHeight()) return false;
        if (getTileMap().isHazard(tileX, tileY)) return false;

        int playerTileX = getTileMap().worldToTileX(player.getCenterX());
        int playerTileY = getTileMap().worldToTileY(player.getCenterY());

        int distanceX = tileX - playerTileX;
        int distanceY = tileY - playerTileY;

        int distanceSquared = distanceX * distanceX + distanceY * distanceY;
        if (distanceSquared > Config.PLAYER_TARGET_RANGE * Config.PLAYER_TARGET_RANGE) return false;

        targetBounds.set(worldX, worldY, Config.TILE_SIZE, Config.TILE_SIZE);

        if (targetMode == TargetMode.PLACE){
            if (targetBounds.overlaps(player.getCollisionBounds())) return false;
        }

        if (targetMode == TargetMode.PLANT){
            if (getFarmingSystem().getPlant(tileX, tileY) != null) return false;
            ItemType selectedItem = player.getInventory().getItemTypeBySlot(player.getSelectedHotbarSlot());
            boolean validPlantTarget = switch (selectedItem){
                case WHEAT_SEED -> getFarmingSystem().isTilled(tileX, tileY);
                case SAPLING ->
                    getTileMap().isTreePlantable(tileX, tileY) && !getFarmingSystem().isTilled(tileX, tileY);
                default -> false;
            };

            if (!validPlantTarget) return false;
        }

        if (targetMode == TargetMode.TILL){
            if (!getTileMap().isTillable(worldX, worldY)) return false;
        }

        if (getTileMap().isBlocked(tileX, tileY)) return false;

        for (Enemy enemy : getEnemies()) {
            if (targetBounds.overlaps(enemy.getCollisionBounds())) return false;
        }

        return !getDestructibleObjectSystem().overlapsAny(targetBounds);
    }

    @Override
    public CraftingResult tryCraft(String recipeId) {
        Recipe recipe = craftingManager.getRecipeById(recipeId);
        if (recipe == null) throw new IllegalArgumentException("Recipe " + recipeId + " does not exist.");
        CraftingResult result = craftingManager.craft(recipe, player.getInventory());

        if (result.isSuccess() && recipe.getResultType() == ItemType.BOAT_KIT && !progressionState.isBoatKitCrafted()){
            progressionState.markBoatKitCrafted();
            guidanceSystem.handleEvent(GameEvent.BOAT_KIT_CRAFTED, progressionState);
        }

        if (result.isSuccess() && result.getOverflowAmount() > 0){
            getWorldItemSystem().add(new WorldItem(player.getX(), player.getY(), recipe.getResultType(), result.getOverflowAmount()));
        }

        return result;
    }

    public List<Recipe> getAvailableRecipes(){
        List<Recipe> newList = new ArrayList<>();
        for (Recipe recipe : getRecipes()){
            if (craftingManager.isCategoryUnlocked(recipe.getCategory())) newList.add(recipe);
        }
        return newList;
    }

    @Override
    public CraftStatus getCraftStatus(String recipeId) {
        Recipe recipe = craftingManager.getRecipeById(recipeId);

        if (recipe == null) throw new IllegalArgumentException("Recipe " + recipeId + " does not exist.");
        return craftingManager.getCraftStatus(recipe, player.getInventory());
    }

    public int getOwnedQuantity(ItemType itemType){
        return player.getInventory().getQuantity(itemType);
    }

    public void setCheckpoint(float x, float y){
        checkpointX = x;
        checkpointY = y;
    }

    public void respawnPlayer(){
        boolean guardianWasActive = isGuardianEncounterActive();
        boolean crimsonWasActive = isCrimsonVeilActive();
        boolean lastVeilWasActive = ashenRiteSystem.isLastVeil();

        if (guardianWasActive) resetActiveGuardianEncounter();

        if (crimsonWasActive) {
            getEnemies().clear();
            getProjectileSystem().replaceProjectiles(List.of());
            getEnemySpawnSystem().endNight();
        }

        player.addBrokenHeart();
        player.restoreHealth();

        if (lastVeilWasActive){
            ashenRiteSystem.resetLastVeilAttempt();

            Vector2 ritualCenter = getTileMap().getObjectPosition("Ritual", "ritual_center");
            player.setPosition(ritualCenter.x, ritualCenter.y);

            updateRitualVisibility();
            return;
        }

        player.setPosition(checkpointX, checkpointY);

        if (crimsonWasActive){
            crimsonVeilSystem.restartActiveVeil();
            startCrimsonVeilWave();
            return;
        }

        if (guardianWasActive && dayNightCycle.isNight()) startOrdinaryNightForCurrentArea();
    }

    public void handleTargetAction(int tileX, int tileY, float worldX, float worldY){
        if (targetMode == TargetMode.NONE) return;
        if (!isCurrentTargetValid(tileX, tileY, worldX, worldY)) return;
        if (targetMode == TargetMode.PLACE) placeTarget(tileX, tileY, worldX, worldY);
        else if (targetMode == TargetMode.PLANT) plantTarget(tileX, tileY, worldX, worldY);
        else if (targetMode == TargetMode.TILL) tillTarget(tileX, tileY, worldX, worldY);
    }

    private void placeTarget(int tileX, int tileY, float worldX, float worldY){
        int selectedSlot = player.getSelectedHotbarSlot();
        ItemType itemType = player.getInventory().getItemTypeBySlot(selectedSlot);
        if (itemType == null) return;

        int removed = player.getInventory().removeFromSlot(selectedSlot, 1);
        if (removed == 0) return;

        getDestructibleObjectSystem().createAndAdd(worldX, worldY, itemType.getPlacedObjectType());
        if (player.getInventory().getItemTypeBySlot(selectedSlot) == null) cancelTargeting();
    }

    private void plantTarget(int tileX, int tileY, float worldX, float worldY){
        int selectedSlot = player.getSelectedHotbarSlot();
        ItemType itemType = player.getInventory().getItemTypeBySlot(selectedSlot);
        if (itemType == null) return;

        int removed = player.getInventory().removeFromSlot(selectedSlot, 1);
        if (removed == 0) return;

        if (itemType == ItemType.WHEAT_SEED) getFarmingSystem().plant(CropType.WHEAT, tileX, tileY);
        else if (itemType == ItemType.SAPLING) getFarmingSystem().plantSapling(tileX, tileY);

        if (player.getInventory().getItemTypeBySlot(selectedSlot) == null) cancelTargeting();
    }

    private void tillTarget(int tileX, int tileY, float worldX, float worldY){
        getFarmingSystem().till(tileX, tileY);
        player.getInventory().getSlot(player.getSelectedHotbarSlot()).reduceDurability(1);
    }

    private void handleMatureSaplings(){
        for (int x=0; x < getTileMap().getWidth(); x++){
            for (int y=0; y < getTileMap().getHeight(); y++){
                GrowablePlant plant = getFarmingSystem().getPlant(x, y);
                if (!(plant instanceof Sapling)) continue;
                if (plant.getGrowthStage() != GrowthStage.MATURE) continue;
                if (!isTreeSpawnPositionValid(x, y)) continue; // neko stoji na tileu, sačekaj

                getFarmingSystem().removePlant(x, y);
                getDestructibleObjectSystem().createAndAdd(getTileMap().tileToWorldX(x), getTileMap().tileToWorldY(y), DestructibleObjectType.TREE);
            }
        }
    }

    private boolean isTreeSpawnPositionValid(int tileX, int tileY){
        if (getTileMap().isHazard(tileX, tileY)) return false;
        float worldX = getTileMap().tileToWorldX(tileX);
        float worldY = getTileMap().tileToWorldY(tileY);
        Rectangle treeBounds = new Rectangle(worldX, worldY, Config.TILE_SIZE, Config.TILE_SIZE);

        if (treeBounds.overlaps(player.getCollisionBounds())) return false;

        for (Enemy enemy : getEnemies()) {
            if (treeBounds.overlaps(enemy.getCollisionBounds())) return false;
        }

        return true;
    }

    private void activateAreaAtDock(AreaID areaID){
        if (areaID == null) throw new IllegalArgumentException("Area id cannot be null.");

        AreaRuntime runtime = areaRuntimes.get(areaID);
        boolean firstVisit = runtime == null;

        if (firstVisit){
            runtime = new AreaRuntime(areaManager.getArea(areaID), player, progressionState);
            areaRuntimes.put(areaID, runtime);
        }

        areaManager.setCurrentArea(areaID);
        currentAreaRuntime = runtime;
        player.setAreaEnvironment(runtime.getTileMap(), runtime.getCollisionSystem());
        updateBoatVisibility();

        Vector2 dockArrival = runtime.getTileMap().getObjectPosition("Objects", "dock_arrival");
        checkpointX = dockArrival.x;
        checkpointY = dockArrival.y;
        player.setPosition(dockArrival.x, dockArrival.y);

        activeChest = null;
        cancelTargeting();

        if (firstVisit){
            runtime.getDestructibleObjectSystem().spawnInitialResources(player, getNaturalResourceTypes(areaID));
            initializeAreaSpecificContent(runtime);
        }
    }

    private void prepareAreaAfterTravel(){
        int currentDayCount = dayNightCycle.getDayCount();
        int departureDayCount = currentAreaRuntime.getLastDepartureDayCount();

        if (departureDayCount != -1 && departureDayCount != currentDayCount){
            getEnemies().clear();
            getProjectileSystem().replaceProjectiles(List.of());
            getEnemySpawnSystem().endNight();
        }

        if (dayNightCycle.isNight() && currentAreaRuntime.getOrdinaryNightDayCount() != currentDayCount){
            startOrdinaryNightForCurrentArea();
        }
    }

    @Override
    public boolean travelToArea(AreaID destination){
        if (destination == null) throw new IllegalArgumentException("Destination cannot be null");
        if (crimsonVeilSystem.isActive() || crimsonVeilSystem.isRecovery() || ashenRiteSystem.blocksDayNightCycle())
            return false;

        if (!progressionState.isBoatBuilt()) return false;
        if (!progressionState.isAreaUnlocked(destination)) return false;

        if (destination == areaManager.getCurrentAreaId()) return false;
        if (!isBoatTravelReady()) return false;
        if (!canAffordBoatTravel()) return false;

        currentAreaRuntime.markDeparture(dayNightCycle.getDayCount());
        if (!player.getWallet().spendGold(Config.BOAT_TRAVEL_GOLD)) return false;

        boolean guardianWasActive = isGuardianEncounterActive();
        if (guardianWasActive){
            resetActiveGuardianEncounter();
            if (dayNightCycle.isNight()) startOrdinaryNightForCurrentArea();
        }

        activateAreaAtDock(destination);
        prepareAreaAfterTravel();
        boatTravelCooldownRemaining = Config.BOAT_TRAVEL_COOLDOWN;
        return true;
    }

    public boolean isWorldMapOpenRequested(){
        return worldMapRequested;
    }

    public void clearWorldMapOpenRequest(){
        worldMapRequested = false;
    }

    private boolean tryUseBoat(){
        Rectangle boatInteraction = getTileMap().getObjectRectangle("SpecialRegions", "boat_interaction");

        if (!boatInteraction.overlaps(player.getCollisionBounds())) return false;

        if (!progressionState.isOldJettyFound()){
            progressionState.discoverOldJetty();
            guidanceSystem.handleEvent(GameEvent.OLD_JETTY_DISCOVERED, progressionState);
        }

        if (!progressionState.isBoatBuilt()){
            boolean removed = player.getInventory().removeItem(ItemType.BOAT_KIT, 1);
            if (!removed) return true;

            progressionState.buildBoat();
            updateBoatVisibility();
            guidanceSystem.handleEvent(GameEvent.BOAT_BUILT, progressionState);
            return true;
        }

        if (ashenRiteSystem.isAftermath()){
            ashenRiteSystem.completeGame();
            departureRequested = true;
            return true;
        }

        if (crimsonVeilSystem.isActive() || crimsonVeilSystem.isRecovery()) return true;

        worldMapRequested = true;
        return true;
    }

    public void updateBoatVisibility(){
        getTileMap().setLayerVisible("Boat", progressionState.isBoatBuilt());
    }

    public void initializeAreaSpecificContent(AreaRuntime runtime){
        GuardianEncounterDefinition definition = getGuardianDefinition(runtime.getAreaID());
        if (definition != null) spawnGuardianChest(runtime, definition);
        if (runtime.getAreaID() == AreaID.DARKROOT_ISLE) spawnHollowcaps(runtime);
    }

    private void spawnGuardianChest(AreaRuntime runtime, GuardianEncounterDefinition definition){
        Vector2 chestSpawn = runtime.getTileMap().getObjectPosition("Objects", "scroll_chest_spawn");
        Chest chest = runtime.getDestructibleObjectSystem().createAndAddChest(chestSpawn.x, chestSpawn.y, ChestKind.GUARDIAN);

        ItemStack[] contents = new ItemStack[Config.CHEST_INVENTORY_SIZE];
        contents[7] = new ItemStack(definition.getScrollItem(), 1);
        chest.getChestInventory().replaceContents(contents);
    }

    private void startGuardianEncounter(GuardianEncounterDefinition definition){
        if (progressionState.isWardCleared(definition.getAreaID())) return;

        if (guardianEncounter == null || guardianEncounter.getAreaID() != definition.getAreaID()){
            Rectangle arenaBounds = getTileMap().getObjectRectangle("SpecialRegions", "guardian_arena_region");
            guardianEncounter = new GuardianEncounter(definition.getAreaID(), arenaBounds, definition.getWaveComposition(), false);
        }

        if (!guardianEncounter.start()) return;

        if (definition.getAreaID() == AreaID.WINDY_PLAINS){
            windyGuardianStartedRequested = true;
        }

        getEnemies().clear();
        getProjectileSystem().replaceProjectiles(List.of());
        getEnemySpawnSystem().endNight();

        spawnGuardianWave(guardianEncounter);
    }

    private void spawnGuardianWave(GuardianEncounter encounter) {
        for (Map.Entry<EnemyType, Integer> entry : encounter.getWaveComposition().entrySet()){
            EnemyType enemyType = entry.getKey();
            int amount = entry.getValue();

            for (int i=0; i < amount; i++){
                Enemy spawnedEnemy = getEnemySpawnSystem().spawnEnemyInRegion(enemyType, encounter.getArenaBounds());
                if (spawnedEnemy == null) throw new IllegalStateException("Could not spawn guardian enemy: " + enemyType);
            }
        }
    }

    public boolean isGuardianEncounterActive(){
        return guardianEncounter != null && guardianEncounter.isActive();
    }

    private void updateGuardianEncounter(){
        if (guardianEncounter == null) return;
        if (!guardianEncounter.isActive()) return;
        if (!getEnemies().isEmpty()) return;

        AreaID areaID = currentAreaRuntime.getAreaID();

        guardianEncounter.complete();
        progressionState.clearWard(areaID);

        applyGuardianReward(areaID);
        getProjectileSystem().replaceProjectiles(List.of());

        guardianEncounter = null;
    }

    private void applyGuardianReward(AreaID areaID){
        switch (areaID){
            case WINDY_PLAINS -> {
                progressionState.unlockDash();
                windyGuardianStartedRequested = false;
                rewardRequested = RewardType.SWIFT_STEP;
            }
            case DARKROOT_ISLE -> {
                craftingManager.unlockCategory(CraftingCategory.BLACKTHORN);
                rewardRequested = RewardType.BLACKTHORN_CRAFT;
            }

            case VEILSCAR_PASSAGE -> {
                upgradeToBloodthirst();
                rewardRequested = RewardType.BLOODTHIRST;
            }

            case MAIN_ISLAND ->
                throw new IllegalStateException(
                    "Main Island has no guardian reward."
                );
        }
    }

    public void updateScrollProgression(){
        if (progressionState.isWardCleared(AreaID.WINDY_PLAINS) && !progressionState.isWispNightUnlocked() &&
            player.getInventory().getQuantity(ItemType.SCROLL_I) > 0){
            progressionState.unlockWispNight();
        }

        if (progressionState.isScrollIRead() && !progressionState.isAreaUnlocked(AreaID.DARKROOT_ISLE)){
            progressionState.unlockArea(AreaID.DARKROOT_ISLE);
        }

        if (progressionState.isWardCleared(AreaID.DARKROOT_ISLE) && !progressionState.isWraithNightUnlocked()
            && player.getInventory().getQuantity(ItemType.SCROLL_II) > 0){
            progressionState.unlockWraithNight();
        }

        if (progressionState.isScrollIIRead() && !progressionState.isAreaUnlocked(AreaID.VEILSCAR_PASSAGE)){
            progressionState.unlockArea(AreaID.VEILSCAR_PASSAGE);
        }
    }

    private void resetActiveGuardianEncounter(){
        if (guardianEncounter == null) return;
        if (!guardianEncounter.isActive()) return;

        getEnemies().clear();
        getProjectileSystem().getProjectiles().clear();

        guardianEncounter.reset();
        guardianEncounter = null;
        windyGuardianStartedRequested = false;
    }

    private void handlePlayerHazard(){
        boolean standingOnHazard = getTileMap().isHazardAtWorld(player.getCenterX(), player.getCenterY());
        if (!standingOnHazard) return;

        player.takeHazardDamage(Config.PIT_FALL_DAMAGE);
        cancelTargeting();

        if (player.isDead()) return;
        player.setPosition(checkpointX, checkpointY);
    }

    private GuardianEncounterDefinition getGuardianDefinition(AreaID areaID){
        return switch (areaID){
            case WINDY_PLAINS ->
                new GuardianEncounterDefinition(
                    AreaID.WINDY_PLAINS,
                    ItemType.SCROLL_I,
                    Map.of(
                        EnemyType.SHADE, 4,
                        EnemyType.WISP, 3
                    )
                );

            case DARKROOT_ISLE ->
                new GuardianEncounterDefinition(
                    AreaID.DARKROOT_ISLE,
                    ItemType.SCROLL_II,
                    Map.of(
                        EnemyType.SHADE, 8,
                        EnemyType.WISP, 6,
                        EnemyType.WRAITH, 6
                    )
                );

            case VEILSCAR_PASSAGE ->
                new GuardianEncounterDefinition(
                    AreaID.VEILSCAR_PASSAGE,
                    ItemType.SCROLL_III,
                    Map.of(
                        EnemyType.SHADE, 10,
                        EnemyType.WISP, 10,
                        EnemyType.WRAITH, 10
                    )
                );

            case MAIN_ISLAND -> null;
        };
    }

    private void spawnHollowcaps(AreaRuntime runtime){
        List<Rectangle> hollowcapZones = runtime.getTileMap().getObjectRectangles("ResourceZones", "hollowcap_zone");

        runtime.getDestructibleObjectSystem().spawnObjectsInRegions(DestructibleObjectType.HOLLOWCAP, hollowcapZones,
                                                                    Config.INITIAL_HOLLOWCAP_AMOUNT, player);
    }

    public void applyPersistentState(float checkpointX, float checkpointY, double playTimeSeconds){
        if (playTimeSeconds < 0) throw new IllegalArgumentException("Play time cannot be negative.");

        this.checkpointX = checkpointX;
        this.checkpointY = checkpointY;
        this.totalPlayTimeSeconds = playTimeSeconds;
    }

    private Set<DestructibleObjectType> getNaturalResourceTypes(AreaID areaID){
        return switch (areaID){
            case MAIN_ISLAND,
                 WINDY_PLAINS,
                 DARKROOT_ISLE ->
                EnumSet.of(DestructibleObjectType.TREE, DestructibleObjectType.ROCK);

            case VEILSCAR_PASSAGE ->
                EnumSet.of(DestructibleObjectType.ROCK);
        };
    }

    private void upgradeToBloodthirst(){
        if (player.getInventory().getQuantity(ItemType.BLOODTHIRST_SWORD) > 0) return;
        if (player.getInventory().getQuantity(ItemType.STONE_SWORD) > 0){
            player.getInventory().removeItem(ItemType.STONE_SWORD, 1);
        }
        player.getInventory().addItem(ItemType.BLOODTHIRST_SWORD, 1);
    }

    private boolean tryUseAshenRite(){
        if (currentAreaRuntime.getAreaID() != AreaID.MAIN_ISLAND) return false;

        if (isPlayerNearRitualPoint("ritual_scroll_slot_1")) return tryPlaceRitualScrollI();
        if (isPlayerNearRitualPoint("ritual_scroll_slot_2")) return tryPlaceRitualScrollII();
        if (isPlayerNearRitualPoint("ritual_scroll_slot_3")) return tryPlaceRitualScrollIII();
        if (isPlayerNearRitualPoint("ritual_activator")) return tryPullRitualLever();

        return false;
    }

    private boolean isPlayerNearRitualPoint(String objectName){
        Vector2 point = getTileMap().getObjectPosition("Ritual", objectName);

        float deltaX = point.x - player.getCenterX();
        float deltaY = point.y - player.getCenterY();

        return deltaX * deltaX + deltaY * deltaY <= Config.PLAYER_PICKUP_RANGE * Config.PLAYER_PICKUP_RANGE;
    }

    private boolean tryPlaceRitualScrollI(){
        if (ashenRiteSystem.isScrollIPlaced()) return true;
        if (!progressionState.isScrollIRead()) return true;
        if (player.getInventory().getQuantity(ItemType.SCROLL_I) <= 0) return true;

        player.getInventory().removeItem(ItemType.SCROLL_I, 1);
        ashenRiteSystem.placeScrollI();
        updateRitualVisibility();

        return true;
    }

    private boolean tryPlaceRitualScrollII(){
        if (ashenRiteSystem.isScrollIIPlaced()) return true;
        if (!progressionState.isScrollIIRead()) return true;
        if (player.getInventory().getQuantity(ItemType.SCROLL_II) <= 0) return true;

        player.getInventory().removeItem(ItemType.SCROLL_II, 1);
        ashenRiteSystem.placeScrollII();
        updateRitualVisibility();

        return true;
    }

    private boolean tryPlaceRitualScrollIII(){
        if (ashenRiteSystem.isScrollIIIPlaced()) return true;
        if (!progressionState.isScrollIIIRead()) return true;
        if (player.getInventory().getQuantity(ItemType.SCROLL_III) <= 0) return true;

        player.getInventory().removeItem(ItemType.SCROLL_III, 1);
        ashenRiteSystem.placeScrollIII();
        updateRitualVisibility();

        return true;
    }

    private boolean tryPullRitualLever(){
        if (!ashenRiteSystem.pullLever()) return true;

        updateRitualVisibility();

        if (ashenRiteSystem.getState() == AshenRiteState.REVEAL) startAshenRiteReveal();
        else if (ashenRiteSystem.getState() == AshenRiteState.LAST_VEIL) startLastVeilWave();

        return true;
    }

    public void updateRitualVisibility(){
        if (currentAreaRuntime.getAreaID() != AreaID.MAIN_ISLAND) return;

        getTileMap().setLayerVisible("RitualScrollI", ashenRiteSystem.isScrollIPlaced());
        getTileMap().setLayerVisible("RitualScrollII", ashenRiteSystem.isScrollIIPlaced());
        getTileMap().setLayerVisible("RitualScrollIII", ashenRiteSystem.isScrollIIIPlaced());
        getTileMap().setLayerVisible("RitualLeverPulled", ashenRiteSystem.isLeverPulled());
    }

    private void startAshenRiteReveal(){
        getEnemies().clear();
        getProjectileSystem().replaceProjectiles(List.of());
        getEnemySpawnSystem().endNight();

        guidanceSystem.handleEvent(GameEvent.ASHEN_RITE_REVEAL_STARTED, progressionState);
    }

    private void updateAshenRiteReveal(){
        if (ashenRiteSystem.getState() != AshenRiteState.REVEAL) return;

        if (!guidanceSystem.isAshenRiteRevealComplete()){
            guidanceSystem.ensureAshenRiteRevealActive();
            return;
        }

        ashenRiteSystem.startLastVeil();
        startLastVeilWave();
    }

    private List<EnemyType> getLastVeilWaveTypes(){
        return switch (ashenRiteSystem.getCurrentWave()){
            case 1 -> List.of(EnemyType.SHADE);
            case 2 -> List.of(EnemyType.WISP);
            case 3 -> List.of(EnemyType.WRAITH);
            case 4, 5 -> List.of(EnemyType.SHADE, EnemyType.WISP, EnemyType.WRAITH);
            default -> throw new IllegalStateException("Invalid Last Veil wave");
        };
    }

    private int getLastVeilWaveBudget(){
        return switch (ashenRiteSystem.getCurrentWave()){
            case 1 -> Config.LAST_VEIL_WAVE_1_BUDGET;
            case 2 -> Config.LAST_VEIL_WAVE_2_BUDGET;
            case 3 -> Config.LAST_VEIL_WAVE_3_BUDGET;
            case 4 -> Config.LAST_VEIL_WAVE_4_BUDGET;
            case 5 -> Config.LAST_VEIL_WAVE_5_BUDGET;
            default -> throw new IllegalStateException("Invalid Last Veil wave");
        };
    }

    private void startLastVeilWave(){
        getEnemySpawnSystem().startThreatWave(getLastVeilWaveBudget(), getLastVeilWaveTypes(),
                            Config.LAST_VEIL_WAVE_SPAWN_DURATION);
    }

    private void updateLastVeil(float delta){
        if (!ashenRiteSystem.isLastVeil()) return;

        if (ashenRiteSystem.getCurrentWave() == 5 && !getEnemySpawnSystem().hasPendingSpawns()
            && getEnemies().size() <= 2 && !getEnemies().isEmpty()){

            guidanceSystem.handleEvent(GameEvent.LAST_VEIL_NEAR_END, progressionState);
        }

        if (ashenRiteSystem.isWaitingForNextWave()){
            if (ashenRiteSystem.updateWaveBreak(delta)) startLastVeilWave();
            return;
        }

        if (!getEnemies().isEmpty()) return;
        if (getEnemySpawnSystem().hasPendingSpawns()) return;

        if (ashenRiteSystem.getCurrentWave() >= Config.LAST_VEIL_WAVE_COUNT){
            getEnemySpawnSystem().endNight();
            getProjectileSystem().replaceProjectiles(List.of());

            ashenRiteSystem.completeLastVeil();
            dayNightCycle.forceDay();

            guidanceSystem.handleEvent(GameEvent.LAST_VEIL_COMPLETED, progressionState);
            return;
        }

        int clearedWave = ashenRiteSystem.getCurrentWave();

        switch (clearedWave){
            case 2 -> guidanceSystem.handleEvent(GameEvent.LAST_VEIL_WAVE_2_CLEARED, progressionState);
            case 3 -> guidanceSystem.handleEvent(GameEvent.LAST_VEIL_WAVE_3_CLEARED, progressionState);
            case 4 -> guidanceSystem.handleEvent(GameEvent.LAST_VEIL_WAVE_4_CLEARED, progressionState);
        }

        ashenRiteSystem.beginWaveBreak();

        ashenRiteSystem.beginWaveBreak();
    }

    public void setTargetMode(TargetMode targetMode){this.targetMode = targetMode;}
    public void cancelTargeting(){targetMode = TargetMode.NONE;}
    public void closeChest(){activeChest = null;}

    public AreaManager getAreaManager() {return areaManager;}
    public List<Recipe> getRecipes(){
        return craftingManager.getRecipes();
    }
    public TileMap getTileMap(){return currentAreaRuntime.getTileMap();}
    public Player getPlayer(){return player;}
    public List<Enemy> getEnemies() { return currentAreaRuntime.getEnemies(); }
    public DayNightCycle getDayNightCycle() {return dayNightCycle;}
    public TargetMode getTargetMode() {return targetMode;}
    public Chest getActiveChest() {return activeChest;}
    public FarmingSystem getFarmingSystem() {return currentAreaRuntime.getFarmingSystem();}
    public ProjectileSystem getProjectileSystem() {return currentAreaRuntime.getProjectileSystem();}
    public double getTotalPlayTimeSeconds() {return totalPlayTimeSeconds;}
    public ProgressionState getProgressionState() {return progressionState;}
    public EnemySpawnSystem getEnemySpawnSystem() {return currentAreaRuntime.getEnemySpawnSystem();}
    public float getCheckpointX() {return checkpointX;}
    public float getCheckpointY() {return checkpointY;}
    public List<WorldItem> getGroundItems(){return currentAreaRuntime.getWorldItemSystem().getItems();}
    public List<DestructibleObject> getDestructibleObjects(){return currentAreaRuntime.getDestructibleObjectSystem().getObjects();}
    public DestructibleObjectSystem getDestructibleObjectSystem(){return currentAreaRuntime.getDestructibleObjectSystem();}
    public WorldItemSystem getWorldItemSystem(){return currentAreaRuntime.getWorldItemSystem();}
    public GuidanceSystem getGuidanceSystem(){return guidanceSystem;}
    public List<AreaRuntime> getInitializedAreaRuntimes(){return new ArrayList<>(areaRuntimes.values());}
    public boolean isCrimsonVeilWarning(){return crimsonVeilSystem.isWarning();}
    public boolean isCrimsonVeilActive(){return crimsonVeilSystem.isActive();}
    public boolean isCrimsonVeilRecovery(){return crimsonVeilSystem.isRecovery();}
    public CrimsonVeilSystem getCrimsonVeilSystem(){return crimsonVeilSystem;}
    public AshenRiteSystem getAshenRiteSystem(){return ashenRiteSystem;}
    public boolean isDepartureRequested(){return departureRequested;}
    public void clearDepartureRequest(){departureRequested = false;}

    public AreaRuntime getOrCreateAreaRuntimeForLoad(AreaID areaID){
        if (areaID == null) throw new IllegalArgumentException("Area id cannot be null.");

        AreaRuntime runtime = areaRuntimes.get(areaID);
        if (runtime != null) return runtime;

        runtime = new AreaRuntime(areaManager.getArea(areaID), player, progressionState);
        areaRuntimes.put(areaID, runtime);
        return runtime;
    }

    @Override
    public AreaID getCurrentAreaId(){return areaManager.getCurrentAreaId();}
    @Override
    public boolean isAreaUnlocked(AreaID areaID){return progressionState.isAreaUnlocked(areaID);}
    @Override
    public int getGold(){return player.getWallet().getGold();}
    @Override
    public int getBoatTravelCost(){return Config.BOAT_TRAVEL_GOLD;}
    @Override
    public boolean isBoatTravelReady(){return boatTravelCooldownRemaining <= 0f;}
    @Override
    public boolean canAffordBoatTravel(){
        return player.getWallet().canAfford(Config.BOAT_TRAVEL_GOLD);
    }
    @Override
    public float getBoatTravelCooldownRemaining() {return boatTravelCooldownRemaining;}

    public ItemType getScrollReadRequested() {return scrollReadRequested;}
    public void clearScrollReadRequests(){scrollReadRequested = null;}

    public RewardType getRewardRequested(){return rewardRequested;}
    public void clearRewardRequest(){rewardRequested = null;}

    public boolean isWindyGuardianStartedRequested(){return windyGuardianStartedRequested;}
    public void clearWindyGuardianStartedRequest(){windyGuardianStartedRequested = false;}

    @Override
    public boolean canAfford(ShopItem shopItem){
        if (shopItem == null) throw new IllegalArgumentException("Shop item cannot be null");
        return player.getWallet().canAfford(shopItem.getPrice());
    }

    @Override
    public boolean buyShopItem(ShopItem shopItem){
        if (shopItem == null) throw new IllegalArgumentException("Shop item cannot be null");
        if (!canAfford(shopItem)) return false;

        int overflow = player.getInventory().addItem(shopItem.getItemType(), 1);
        if (overflow > 0) return false;
        player.getWallet().spendGold(shopItem.getPrice());
        return true;
    }

    public void dispose(){
        for (AreaRuntime runtime : areaRuntimes.values()){runtime.dispose();}
    }
}
