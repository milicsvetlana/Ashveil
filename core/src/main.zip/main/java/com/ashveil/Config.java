package com.ashveil;

public class Config {

    /** World scale and rendering */
    public static final int TILE_SIZE = 16;
    public static final float SCALE = 2.5f;
    public static final float TILE_DRAW_SIZE = TILE_SIZE * SCALE;

    /** Screen and camera */
    public static final int SCREEN_WIDTH = 1280;
    public static final int SCREEN_HEIGHT = 720;
    public static final float CAMERA_SMOOTHING = 12f;

    /** Player movement and interaction */
    public static final float PLAYER_SPEED = 100f;
    public static final float PLAYER_PICKUP_RANGE = TILE_SIZE * 2;
    public static final float PLAYER_TARGET_RANGE = 5;

    /** Player combat */
    public static final int PLAYER_BASE_DAMAGE = 1;
    public static final float DAMAGE_COOLDOWN_MAX = 1f;
    public static final float PLAYER_PRIMARY_ACTION_RANGE = 60f;
    public static final float PLAYER_PRIMARY_ACTION_MIN_DOT = 0.75f;
    public static final float PLAYER_PRIMARY_ACTION_COOLDOWN = 0.75f;

    /** Player health and death */
    public static final int PLAYER_HP = 10;
    public static final int PLAYER_HEART_SLOTS = 5;
    public static final int HP_PER_HEART = 2;
    public static final int MAX_BROKEN_HEARTS = 3;
    public static final int BREAD_HEALING = 1;
    public static final int HOLLOWCAP_HEALING = 2;
    public static final float DEATH_FADE_DURATION = 2f;

    public static final int PIT_FALL_DAMAGE = HP_PER_HEART;

    /** Inventory */
    public static final int INVENTORY_SIZE = 20;
    public static final int CHEST_INVENTORY_SIZE = 15;
    public static final int HOTBAR_SIZE = 5;
    public static final int SLOT_NOT_SELECTED = -1;
    public static final int SLOT_MOVE = 1;

    /** Day and night cycle */
    public static final float FIRST_DAY_DURATION = 180f;

    public static final float DAY_NIGHT_CYCLE_DURATION = 210f;

    public static final float DAY_PHASE_RATIO = 0.60f;
    public static final float DUSK_PHASE_RATIO = 0.10f;
    public static final float NIGHT_PHASE_RATIO = 0.30f;

    public static final float DAY_DURATION = DAY_NIGHT_CYCLE_DURATION * DAY_PHASE_RATIO;
    public static final float DUSK_DURATION = DAY_NIGHT_CYCLE_DURATION * DUSK_PHASE_RATIO;
    public static final float NIGHT_DURATION = DAY_NIGHT_CYCLE_DURATION * NIGHT_PHASE_RATIO;

    /** Ground items */
    public static final float WORLD_ITEM_MERGE_RANGE = TILE_SIZE * 2;
    public static final float WORLD_ITEM_DESPAWN_TIME = 300f;
    public static final int WORLD_MAX_NUMBER_OF_ITEMS = 250;

    /** Resource generation */
    public static final int MAX_EXTRA_INITIAL_RESOURCES = 49;
    public static final int MIN_INITIAL_RESOURCES = 10;
    public static final int INITIAL_SPAWN_CLEAR_RADIUS = 2;

    /** Resource stats and drops */
    public static final int TREE_HP = 5;
    public static final int ROCK_HP = 7;
    public static final int FENCE_HP = 4;
    public static final int THORN_FENCE_HP = 10;
    public static final int BRIAR_SNARE_HP = 1;
    public static final int CHEST_HP = 4;
    public static final int HOLLOWCAP_HP = 1;
    public static final int FIRST_TREE_DROP_AMOUNT = 2;

    /** Enemy lifecycle */
    public static final float ENEMY_DYING_DURATION = 0.5f;
    public static final float ENEMY_HP_BAR_DURATION = 1.5f;
    public static final float ENEMY_HIT_FLASH_DURATION = 0.15f;
    public static final float ENEMY_AI_DECISION_INTERVAL = 0.15f;
    public static final float ENEMY_ATTACK_COOLDOWN = 1f;

    public static final float WISP_CHARGE_RANGE = TILE_SIZE * 5f;
    public static final float WISP_CHARGE_DURATION = 0.6f;
    public static final float WISP_DASH_SPEED = 180f;
    public static final float WISP_DASH_DURATION = 0.45f;
    public static final float WISP_RECOVERY_DURATION = 0.7f;
    public static final float WRAITH_RETREAT_RANGE = TILE_SIZE * 3f;
    public static final float WRAITH_ATTACK_RANGE = TILE_SIZE * 7f;
    public static final float WRAITH_ATTACK_COOLDOWN = 1.5f;
    public static final float WRAITH_PROJECTILE_SPEED = 70f;
    public static final float WRAITH_PROJECTILE_LIFETIME = 4f;

    /** Gold drops */
    public static final int DOUBLE_GOLD_DROP_CHANCE = 20;
    public static final int SINGLE_GOLD_DROP_CHANCE = 60;

    public static final int SAPLING_DROP_CHANCE = 40; // npr 40% šanse

    /** Farming */
    public static final float WHEAT_EARLY_DURATION = 3f;
    public static final float WHEAT_MIDDLE_DURATION = 3f;
    public static final float WHEAT_LATE_DURATION = 3f;
    public static final float SAPLING_EARLY_DURATION = 5f;
    public static final float SAPLING_MIDDLE_DURATION = 5f;
    public static final float SAPLING_LATE_DURATION = 5f;

    /** Enemy Spawn/Despawn */
    public static final int INITIAL_NIGHT_THREAT_BUDGET = 3;
    public static final int NIGHT_THREAT_BUDGET_INCREASE = 2;
    public static final int ENEMY_SPAWN_MIN_TILE_DISTANCE = 20;
    public static final int ENEMY_SPAWN_MAX_TILE_DISTANCE = 28;
    public static final int ENEMY_SPAWN_MAX_ATTEMPTS = 50;

    public static final float ENEMY_FLEE_SPEED = 110f;

    /** Loading Screen */
    public static final float LOADING_FADE_IN_DURATION = 0.25f;
    public static final float LOADING_MIN_VISIBLE_DURATION = 1f;
    public static final float LOADING_FADE_OUT_DURATION = 0.25f;


    public static final int GUIDANCE_WOOD_TARGET = 5;

    /** Travel */
    public static final int BOAT_TRAVEL_GOLD = 5;
    public static final float BOAT_TRAVEL_COOLDOWN = 20f;

    public static final float CHEST_WORLD_SIZE = 35.2f;

    public static final float PLAYER_DASH_DISTANCE = TILE_SIZE * 4f;
    public static final float PLAYER_DASH_COOLDOWN = 0.75f;

    public static final int THORN_FENCE_RETALIATION_DAMAGE = 2;
    public static final float BRIAR_SNARE_ROOT_TIMER = 3f;
    public static final int BRIAR_SNARE_DAMAGE = 1;
    public static final int INITIAL_HOLLOWCAP_AMOUNT = 20;

    /** Crimson Veil */
    public static final int CRIMSON_VEIL_FIRST_DAY_MIN = 5;
    public static final int CRIMSON_VEIL_FIRST_DAY_MAX = 6;

    public static final int CRIMSON_VEIL_INTERVAL_MIN = 4;
    public static final int CRIMSON_VEIL_INTERVAL_MAX = 6;

    public static final int CRIMSON_VEIL_WAVE_COUNT = 3;

    public static final int CRIMSON_VEIL_BASE_BONUS_BUDGET = 10;
    public static final int CRIMSON_VEIL_COMPLETED_BONUS_BUDGET = 4;

    public static final float CRIMSON_VEIL_WAVE_1_SHARE = 0.25f;
    public static final float CRIMSON_VEIL_WAVE_2_SHARE = 0.35f;

    public static final float CRIMSON_VEIL_WAVE_MAX_DURATION = 25f;
    public static final float CRIMSON_VEIL_CLEAR_GRACE_DURATION = 5f;
    public static final float CRIMSON_VEIL_WAVE_SPAWN_DURATION = 8f;
    public static final float CRIMSON_VEIL_RECOVERY_DURATION = 3f;

    /** Ashen Rite, Last Veil */

    public static final int LAST_VEIL_WAVE_COUNT = 5;

    public static final int LAST_VEIL_WAVE_1_BUDGET = 8;
    public static final int LAST_VEIL_WAVE_2_BUDGET = 12;
    public static final int LAST_VEIL_WAVE_3_BUDGET = 15;
    public static final int LAST_VEIL_WAVE_4_BUDGET = 24;
    public static final int LAST_VEIL_WAVE_5_BUDGET = 32;

    public static final float LAST_VEIL_WAVE_SPAWN_DURATION = 6f;
    public static final float LAST_VEIL_WAVE_BREAK_DURATION = 8f;
}
