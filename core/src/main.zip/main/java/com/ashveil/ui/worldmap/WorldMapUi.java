package com.ashveil.ui.worldmap;

import com.ashveil.world.WorldMapAccess;
import com.ashveil.world.area.AreaID;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;

import java.util.EnumMap;
import java.util.Map;

public class WorldMapUi implements Disposable {
    private final Stage stage;
    private final Skin skin;
    private final WorldMapAccess worldMapAccess;

    private static final float DESIGN_WIDTH = 3840f;
    private static final float DESIGN_HEIGHT = 2160f;

    private final Texture backgroundTexture;
    private final Image backgroundImage;

    private final Texture statusBarTexture;
    private final Image statusBarImage;
    private final Label statusLabel;

    private final Texture lockedMarkerTexture;
    private final Texture availableMarkerTexture;
    private final Texture currentMarkerTexture;
    private final Texture selectedMarkerTexture;

    private final Map<AreaID, Image> markers;
    private AreaID selectedAreaId;

    private final TextButton closeButton;
    private final TextButton travelButton;

    private boolean closeRequested;
    private AreaID travelRequestedArea;

    public WorldMapUi(Skin skin, WorldMapAccess worldMapAccess){
        if (skin == null) throw new IllegalArgumentException("Skin cannot be null");
        if (worldMapAccess == null) throw new IllegalArgumentException("World map access cannot be null.");

        this.skin = skin;
        this.worldMapAccess = worldMapAccess;
        this.stage = new Stage(new FitViewport(DESIGN_WIDTH, DESIGN_HEIGHT));

        backgroundTexture = new Texture(Gdx.files.internal("ui/world-map/world-map.png"));
        backgroundTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        backgroundImage = new Image(backgroundTexture);

        statusBarTexture = new Texture(Gdx.files.internal("ui/world-map/world-map-status-bar.png"));
        statusBarTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        statusBarImage = new Image(statusBarTexture);

        statusLabel = new Label("Good to go.", skin);
        statusLabel.setAlignment(Align.center);
        statusLabel.setFontScale(2f);

        lockedMarkerTexture = new Texture(Gdx.files.internal("ui/world-map/world-map-marker-locked.png"));
        availableMarkerTexture = new Texture(Gdx.files.internal("ui/world-map/world-map-marker-available.png"));
        currentMarkerTexture = new Texture(Gdx.files.internal("ui/world-map/world-map-marker-current.png"));
        selectedMarkerTexture = new Texture(Gdx.files.internal("ui/world-map/world-map-marker-selected.png"));

        lockedMarkerTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        availableMarkerTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        currentMarkerTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        selectedMarkerTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        markers = new EnumMap<>(AreaID.class);
        selectedAreaId = null;

        closeButton = new TextButton("CLOSE MAP", skin, "save-slot-action");
        travelButton = new TextButton("TRAVEL", skin, "save-slot-action");

        closeButton.getLabel().setFontScale(2.5f);
        travelButton.getLabel().setFontScale(2.5f);

        closeRequested = false;
        travelRequestedArea = null;

        createLayout();
    }

    private void createLayout(){
        backgroundImage.setBounds(0f, 0f, DESIGN_WIDTH, DESIGN_HEIGHT);
        stage.addActor(backgroundImage);

        Image mainIslandMarker = createMarker(AreaID.MAIN_ISLAND, currentMarkerTexture, 1750f, 1020f, 260f, 260f);
        Image windyPlainsMarker = createMarker(AreaID.WINDY_PLAINS, availableMarkerTexture, 2680f, 1400f, 220f, 220);
        Image darkrootIsleMarker = createMarker(AreaID.DARKROOT_ISLE, lockedMarkerTexture, 850f, 980f, 220f, 220);
        Image veilscarPassageMarker = createMarker(AreaID.VEILSCAR_PASSAGE, lockedMarkerTexture, 2660f, 650f, 220f, 220f);

        stage.addActor(mainIslandMarker);
        stage.addActor(windyPlainsMarker);
        stage.addActor(darkrootIsleMarker);
        stage.addActor(veilscarPassageMarker);

        statusBarImage.setBounds(1420f, 175f, 1000f, 280f);
        statusLabel.setBounds(1420f, 235f, 1000f, 160f);

        stage.addActor(statusBarImage);
        stage.addActor(statusLabel);

        closeButton.setBounds(1320f, 70f, 560f, 150f);
        travelButton.setBounds(1960f, 70f, 560f, 150f);

        closeButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent changeEvent, Actor actor) {
                closeRequested = true;
            }
        });

        travelButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent changeEvent, Actor actor) {
                travelRequestedArea = selectedAreaId;
            }
        });

        stage.addActor(closeButton);
        stage.addActor(travelButton);
    }

    private Image createMarker(AreaID areaID, Texture texture, float x, float y, float size1, float size2){
        Image marker = new Image(texture);

        marker.setSize(size1, size2);
        marker.setPosition(x, y);

        marker.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                if (getMarkerState(areaID) != WorldMapMarkerState.AVAILABLE) return;

                selectedAreaId = areaID;
                refresh();
            }
        });

        markers.put(areaID, marker);

        return marker;
    }

    public void refresh(){
        refreshMarkers();
        refreshTravelState();
    }

    private WorldMapMarkerState getMarkerState(AreaID areaID){
        if (areaID == worldMapAccess.getCurrentAreaId()) return WorldMapMarkerState.CURRENT;
        if (!worldMapAccess.isAreaUnlocked(areaID)) return WorldMapMarkerState.LOCKED;
        if (areaID == selectedAreaId) return WorldMapMarkerState.SELECTED;
        return WorldMapMarkerState.AVAILABLE;
    }

    private Texture getMarkerTexture(WorldMapMarkerState state){
        return switch (state){
            case LOCKED -> lockedMarkerTexture;
            case AVAILABLE -> availableMarkerTexture;
            case CURRENT -> currentMarkerTexture;
            case SELECTED -> selectedMarkerTexture;
        };
    }

    private void refreshMarkers(){
        for (Map.Entry<AreaID, Image> entry : markers.entrySet()){
            AreaID areaID = entry.getKey();
            Image marker = entry.getValue();

            WorldMapMarkerState state = getMarkerState(areaID);
            Texture texture = getMarkerTexture(state);

            marker.setDrawable(new TextureRegionDrawable(new TextureRegion(texture)));
        }
    }

    private void refreshTravelState(){
        boolean travelAvailable = selectedAreaId != null && worldMapAccess.isBoatTravelReady() && worldMapAccess.canAffordBoatTravel();

        travelButton.setDisabled(!travelAvailable);
        statusLabel.setText(createStatusText());
    }

    private String createStatusText(){
        int gold = worldMapAccess.getGold();
        int cost = worldMapAccess.getBoatTravelCost();

        if (!worldMapAccess.isBoatTravelReady()){
            int seconds = Math.max(1, (int) Math.ceil(worldMapAccess.getBoatTravelCooldownRemaining()));
            return "Gold: " + gold + " | Travel cooldown: " + seconds + "s | Cost: " + cost;
        }

        if (selectedAreaId == null){
            return "Gold: " + gold + "   |   Select a destination   |   Cost: " + cost;
        }

        if (!worldMapAccess.canAffordBoatTravel()){
            return "Gold: " + gold + "   |   Not enough gold   |   Cost: " + cost;
        }

        return "Gold: " + gold + "   |   Ready to travel   |   Cost: " + cost;
    }

    public void onOpen(){
        selectedAreaId = null;
        closeRequested = false;
        travelRequestedArea = null;
        refresh();
    }
    public void act(float delta){
        refreshTravelState();
        stage.act(delta);
    }
    public void draw(){stage.draw();}
    public void resize(int width, int height){stage.getViewport().update(width, height,true);}

    public Stage getStage(){return stage;}

    @Override
    public void dispose(){
        stage.dispose();
        backgroundTexture.dispose();
        lockedMarkerTexture.dispose();
        availableMarkerTexture.dispose();
        currentMarkerTexture.dispose();
        selectedMarkerTexture.dispose();
        statusBarTexture.dispose();
    }

    public boolean isCloseRequested(){return closeRequested;}
    public void clearCloseRequest(){closeRequested = false;}
    public AreaID getTravelRequestedArea(){return travelRequestedArea;}
    public void clearTravelRequest(){travelRequestedArea = null;}
}
