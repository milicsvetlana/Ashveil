package com.ashveil.ui.panels;

import com.ashveil.items.crafting.*;
import com.ashveil.items.inventory.ItemType;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;

import java.util.List;
import java.util.Map;

//sadrzace kasnije listu recepata, kategorije kao obicne naslove, details panel, crafting dugme
public class CraftingPanel extends MenuPanel {

    private final Table recipeListTable;
    private final ScrollPane recipeScrollPane;
    private final Table detailsTable;
    private final List<Recipe> recipes;
    private final CraftingAccess craftingAccess;
    private Recipe selectedRecipe;
    private TextButton selectedRecipeButton;
    private String craftingMessage;
    private final Runnable onCraftSuccess;

    public CraftingPanel(Skin skin, List<Recipe> recipes, CraftingAccess craftingAccess, Runnable onCraftSuccess) {
        super(skin);
        this.recipes = recipes;
        this.craftingAccess = craftingAccess;
        this.onCraftSuccess = onCraftSuccess;

        recipeListTable = new Table();
        detailsTable = new Table();
        recipeScrollPane = new ScrollPane(recipeListTable);

        createLayout();
        createRecipeList();
        refreshDetails();
    }

    @Override
    public void refresh() {
        craftingMessage = null;
        refreshDetails();
    }

    @Override
    public void onHide() {
        if (selectedRecipeButton != null) selectedRecipeButton.setChecked(false);

        selectedRecipeButton = null;
        selectedRecipe = null;
        craftingMessage = null;

        refreshDetails();
    }

    private void createLayout(){
        recipeListTable.top().left();
        detailsTable.top().left();
        add(recipeScrollPane).width(300).growY();
        add(detailsTable).grow().padLeft(20);
    }

    private void createRecipeList(){
        recipeListTable.clearChildren();

        for (CraftingCategory category : CraftingCategory.values()){
            Label categoryLabel = new Label(category.name(), getSkin());

            recipeListTable.add(categoryLabel).left().padTop(12).padBottom(5);
            recipeListTable.row();

            for (Recipe recipe : recipes){
                if (recipe.getCategory() == category){
                    TextButton recipeButton = new TextButton(recipe.getResultType().getDisplayName(), getSkin());
                    recipeButton.setProgrammaticChangeEvents(false);

                    recipeListTable.add(recipeButton).growX().left().padBottom(4);
                    recipeListTable.row();

                    recipeButton.addListener(new ChangeListener() {
                        @Override
                        public void changed(ChangeEvent changeEvent, Actor actor) {
                            selectRecipe(recipe, recipeButton);
                        }
                    });
                }
            }
        }
    }

    private void selectRecipe(Recipe recipe, TextButton recipeButton){
        if (selectedRecipeButton != null && selectedRecipeButton != recipeButton) {
            selectedRecipeButton.setChecked(false);
        }

        selectedRecipe = recipe;
        selectedRecipeButton = recipeButton;
        selectedRecipeButton.setChecked(true);

        craftingMessage = null;
        refreshDetails();
    }

    private void refreshDetails(){
        detailsTable.clearChildren();
        if (selectedRecipe == null) {
            detailsTable.add(new Label("Select a recipe", getSkin()));
            return;
        }

        detailsTable.add(new Label(selectedRecipe.getResultType().getDisplayName(), getSkin()));
        detailsTable.row();

        detailsTable.add(new Label("Required:", getSkin()));
        detailsTable.row();

        for (Map.Entry<ItemType, Integer> ingredient : selectedRecipe.getIngredients().entrySet()){
            ItemType itemType = ingredient.getKey();
            int requiredQuantity = ingredient.getValue();

            detailsTable.add(new Label(itemType.getDisplayName() + ": " + craftingAccess.getOwnedQuantity(itemType) + " / " + requiredQuantity, getSkin()));
            detailsTable.row();
        }

        detailsTable.add(new Label("Produces: " + selectedRecipe.getResultType().getDisplayName() +
                                    " x " + selectedRecipe.getResultAmount(), getSkin()));
        detailsTable.row();

        TextButton craftButton = new TextButton("CRAFT", getSkin());

        CraftStatus status = craftingAccess.getCraftStatus(selectedRecipe.getId());
        craftButton.setDisabled(status != CraftStatus.SUCCESS);

        detailsTable.add(craftButton).left().padTop(10);
        detailsTable.row();
        craftButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent changeEvent, Actor actor) {
                craftSelectedRecipe();
            }
        });
        if (craftingMessage != null) {
            detailsTable.add(new Label(craftingMessage, getSkin())).left().padTop(8);
            detailsTable.row();
        }

    }

    private void craftSelectedRecipe() {
        CraftingResult result = craftingAccess.tryCraft(selectedRecipe.getId());
        if (result.isSuccess() && onCraftSuccess != null) onCraftSuccess.run();

        if (result.isSuccess()) {
            craftingMessage = "Crafted: " + selectedRecipe.getResultType().getDisplayName();
            if (result.getOverflowAmount() > 0) {
                craftingMessage += " (" + result.getOverflowAmount() + " dropped nearby)";
            }
        }
        else craftingMessage = "Crafting failed.";

        refreshDetails();
    }
}
